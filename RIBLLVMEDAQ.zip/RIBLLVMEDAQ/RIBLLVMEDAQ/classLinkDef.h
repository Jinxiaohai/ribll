#ifdef __CINT__
#pragma link C++ class TBoard;
#pragma link C++ class TControl;
#pragma link C++ class TModV785;
#pragma link C++ class TModV785N;
#pragma link C++ class TModV775;
#pragma link C++ class TModV775N;
#pragma link C++ class TModV830AC;
#pragma link C++ class TModV792;
#pragma link C++ class TEvtBuilder;
#pragma link C++ class TClientEvtBuilder;
#pragma link C++ class TControlFrame+;
#pragma link C++ class TMasterTask;
#endif
